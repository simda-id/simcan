# simda perencanaan
Kode sumber aplikasi SIMDA Perencanaan yang dikembangkan oleh [Tim Aplikasi](http://www.simda-online.com).

### Rilis Terakhir dan Dokumentasi

1. Dapatkan [rilis terakhir di sini](https://github.com/simda-id/simcan/releases). 
2. Dokumentasi sederhana [tersedia di sini](https://github.com/simda-id/simcan/wiki).
3. Pedoman instalasi [dapat dibaca di sini](https://github.com/simda-id/simcan/blob/master/installing.md).
4. Pedoman update aplikasi [dapat dibaca di sini](https://github.com/simda-id/simcan/blob/master/updating.md).

#### Lisensi
APLIKASI SIMDA PERENCANAAN DAPAT DIPERGUNAKAN TANPA BIAYA, DENGAN MENYEBUTKAN HAK CIPTA PADA [Badan Pengawasan Keuangan dan Pembangunan](http://www.bpkp.go.id). ANDA TIDAK DIPERKENANKAN MENGGUNAKAN APLIKASI INI UNTUK TUJUAN KOMERSIAL. PERUBAHAN DAN ATAU PENAMBAHAN FITUR YANG ANDA KEMBANGKAN HARUS DIRILIS TERBUKA UNTUK DAPAT DIPERGUNAKAN OLEH SEMUA PIHAK TANPA BIAYA.

#### Berpartisipasi
Dapat disampaikan melalui [timaplikasi et yahoo titik com](http://www.simda-online.com) atau melalui [issues wiki](https://github.com/simda-id/simcan/issues).
