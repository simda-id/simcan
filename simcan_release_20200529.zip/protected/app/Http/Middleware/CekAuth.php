<?php //00523
// powerby:simda-perencanaan@simda.bpkp
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvOqDDJM7OqRtu6XzoiYCoclgFZ85laOVAF8dOq0wC4UTuzxrdjdoRPhhjQMzGdNrIvRHtQT
w1I/3b07WB6Vp7rxMyaMStQ6wO3BnMJ4b4cnAVXzY48HRSgKgWuwNQbR+hdbHWobkxCenzFMmvER
JY/2QPnZEcL+gnPM6957/HdvY3xij2LoMGmHKRu/AeTb1n0fyJucGNckCqyPLaYULh6LXYOQGhqz
BfiQXFR7dTLaVzHZPMgv9QEnhwWVEQSYkXifcywYKyDESdtr5OSvtzJA+dy4z0vauh3kZlP4yFmR
Sn3CRx8BquvjhGZTukf57+1Y4Pvd4tWfe+GYVksGHE/YPeZSCoxOGY1vER9H7pS55/KXhT7qUPi1
LqdpQW/siNNS7s01R0xvpe8NOHV/8zv7ZtyKX9WN4DFL0dIv1glclX/aPzGjE4BxoSpJPomA23G6
zqYPJR2KD690LPD8gLKW+i/Q9LY6ujL/usBDwKcUgSySxdL6bqe41uOu4aU6Mx4OXe64y24GR1So
bM0pevE0QP67U62BHVhnMjbHcMiVJ/jCwtQOBAKJBy3jgRByUw+8zTdMCdUW+FpkTNPf4x6LL3b4
NvGRBtfm4ufd2H2Z2ym88Xj0UsQRAyCeSf6At00+LIrQvtJTXXAxiqYp4Buz2m9giLWg/xUS+6iP
s2hGHx9JhvKQ8e/5BuySbDnj6Z9BMjxDNdCM2vdQjeEUBjitAQ2g0jKs7XPv8MsDRxuKYQUFmSLo
LETvI+oZyHYxvqNX1tHEO6I/HNL3r5Wfso4UhJYC9g2K/JWLPWsD3ZEvwvRIz/xP1myuIJIZS+F2
EMg2xO8cnFaao/q3rftKH1WvQfKgi7q4hz/bTBv2+qsxMoQfTwpRJoK9iGVq+P+u/xTrCN7xDHSK
twmlqlo7H94IC7VAq4Krepbz/oG6oFuP9x+N1XlH6mFD0pa3OCJsB+wqsci1DiU8zjSO2XVIBB0X
bgSK+Fc1WdorDTOfY81fVJ0Y6TW3+LID7hVCFR0ZF+1tyuJ38M+5sAUr8bSxjx/l9fHuqcwDRlRR
eExsc2jT57hsCLCxyJ43yoTKeztWIJWYn+ZsaAdoGgtV+m8uQL9mj9B5IuRUNHhdQgEuLXW/n8YB
J3Z91csim9pHPioYVdDEaWEFA1k1KQw8AaLleZuH3dxJCpgmP2tGb/v0+4R4mtdxYKBub4auSUq6
m84i9MaSeFnOkM62ymaPpoqSAp1E8v1CxVOdtmI/aT3sc46Paej4arX30N8mGAyq7OmeGAFi3MWI
AwrqFs0QEYrUBbTd7AWdaFh/zu5zA/HTpS3TfPfDY2bRPIEByIxMTVgsS9A153uxqfDImL2TSaa7
JH/1o6pB7S/wqUlwkVcI7jMNDUsYJ+dBx9ZqCjHzLGtP9GnrZzq87YOzQ0hoaz6fk2BGnZBE+/Al
BMobtEj6DteQQVAblr/MkhISxrW=